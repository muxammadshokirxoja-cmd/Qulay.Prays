const { app, BrowserWindow, shell, Menu, ipcMain } = require("electron");
const path = require("path");
const fs = require("fs");
const cfg = require("./package.json");
// Admin versiyasi alohida ma'lumot papkasida ishlaydi
if (cfg.dataName) app.setPath("userData", path.join(app.getPath("appData"), cfg.dataName));

// Dastur faqat bitta oynada ishlaydi
if (!app.requestSingleInstanceLock()) { app.quit(); }

const UPD_NAME = cfg.updName || "Qulay-Prays.html";
const bundled = () => path.join(__dirname, ...String(cfg.startFile || "app/Qulay-Prays.html").split("/"));
const updDir = () => path.join(app.getPath("userData"), "updates");
const updFile = () => path.join(updDir(), UPD_NAME);
const MARK = /QULAY-PRAYS-BUILD:(\d+)-->/;
function buildOf(f) {
  try { const m = fs.readFileSync(f, "utf8").match(MARK); return m ? +m[1] : 0; } catch (e) { return 0; }
}
// O'rnatilgan fayl bilan yuklab olingan yangilanishdan qaysi biri yangi bo'lsa, shu ochiladi
function pickFile() {
  const b = buildOf(bundled()), u = buildOf(updFile());
  return u > b ? updFile() : bundled();
}

let win = null;
function createWindow() {
  Menu.setApplicationMenu(null);
  win = new BrowserWindow({
    width: 1280, height: 800, minWidth: 900, minHeight: 600,
    show: false, autoHideMenuBar: true, title: "Qulay Prays",
    frame: true, resizable: true, minimizable: true, maximizable: true, closable: true, fullscreenable: false,
    icon: path.join(__dirname, "build", "icon.ico"),
    webPreferences: { contextIsolation: true, nodeIntegration: false, sandbox: true, preload: path.join(__dirname, "preload.js") }
  });
  win.maximize();
  win.once("ready-to-show", () => win.show());
  win.loadFile(pickFile());
  // Yangilangan fayl ochilmasa, o'rnatilgan fayl ochiladi
  win.webContents.on("did-fail-load", (e, code, desc, url, isMain) => {
    if (isMain && url && url.indexOf("updates") >= 0) win.loadFile(bundled());
  });
  // Telegram va boshqa tashqi havolalar oddiy brauzerda ochiladi
  win.webContents.setWindowOpenHandler(({ url }) => {
    if (/^https?:\/\//i.test(url)) shell.openExternal(url);
    return { action: "deny" };
  });
  win.webContents.on("will-navigate", (e, url) => { if (!url.startsWith("file://")) { e.preventDefault(); if (/^https?:\/\//i.test(url)) shell.openExternal(url); } });
  win.on("closed", () => { win = null; });
}

const fromApp = (e) => !!(e.senderFrame && String(e.senderFrame.url).startsWith("file://"));
ipcMain.handle("qp:save", (e, text, build) => {
  if (!fromApp(e)) throw new Error("not allowed");
  text = String(text || "");
  const m = text.match(MARK);
  if (text.length < 100000 || text.indexOf("</html>") < 0 || !m || +m[1] !== +build) throw new Error("bad file");
  fs.mkdirSync(updDir(), { recursive: true });
  const tmp = updFile() + ".tmp";
  fs.writeFileSync(tmp, text, "utf8");
  fs.renameSync(tmp, updFile());
  return true;
});
// Telegram (faqat admin dasturida: admin-builder.json -> extraMetadata.tg = true)
let TG = null;
if (cfg.tg) { try { TG = require("./tg.js"); } catch (e) { TG = null; } }
ipcMain.handle("qp:tg", async (e, cmd, arg) => {
  if (!fromApp(e)) throw new Error("not allowed");
  if (!TG) throw new Error("Telegram bu dasturda o'rnatilmagan");
  return TG.run(String(cmd), arg || {});
});
ipcMain.handle("qp:togglemax", (e) => { if (fromApp(e) && win) { if (win.isMaximized()) win.unmaximize(); else win.maximize(); } return true; });
ipcMain.handle("qp:ismax", (e) => !!(fromApp(e) && win && win.isMaximized()));
ipcMain.handle("qp:reload", (e) => { if (fromApp(e) && win) win.loadFile(pickFile()); return true; });

app.on("second-instance", () => { if (win) { if (win.isMinimized()) win.restore(); win.focus(); } });
app.whenReady().then(createWindow);
app.on("window-all-closed", () => app.quit());
