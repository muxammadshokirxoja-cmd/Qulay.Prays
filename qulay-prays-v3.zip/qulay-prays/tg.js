// Qulay Prays — Telegram ulanishi (faqat admin dasturida ishlaydi)
// Akkauntlar orqali tanlangan kanal/guruhlardagi yangi Excel prayslarni yig'adi.
const path = require("path");
const fs = require("fs");
const crypto = require("crypto");
const { app, safeStorage } = require("electron");
const { TelegramClient, Api } = require("telegram");
const { StringSession } = require("telegram/sessions");

const EXT = /\.(xlsx|xls|csv)$/i;
const FIRST_DAYS = 3;            // birinchi marta: oxirgi 3 kunlik prayslar olinadi
const MAX_FILE = 30 * 1024 * 1024;

const cfgFile = () => path.join(app.getPath("userData"), "telegram.json");
let cfg = null;
function load() {
  if (cfg) return cfg;
  try { cfg = JSON.parse(fs.readFileSync(cfgFile(), "utf8")); } catch (e) { cfg = null; }
  if (!cfg || typeof cfg !== "object") cfg = {};
  cfg.apiId = cfg.apiId || 0; cfg.apiHash = cfg.apiHash || "";
  cfg.accounts = Array.isArray(cfg.accounts) ? cfg.accounts : [];
  cfg.seen = cfg.seen || {};
  return cfg;
}
function save() {
  fs.mkdirSync(path.dirname(cfgFile()), { recursive: true });
  const tmp = cfgFile() + ".tmp";
  fs.writeFileSync(tmp, JSON.stringify(cfg), "utf8");
  fs.renameSync(tmp, cfgFile());
}
// Sessiya va api_hash kompyuterning o'zida shifrlab saqlanadi
function enc(s) {
  s = String(s || "");
  try { if (safeStorage.isEncryptionAvailable()) return "e:" + safeStorage.encryptString(s).toString("base64"); } catch (e) {}
  return "p:" + Buffer.from(s, "utf8").toString("base64");
}
function dec(s) {
  s = String(s || "");
  try {
    if (s.startsWith("e:")) return safeStorage.decryptString(Buffer.from(s.slice(2), "base64"));
    if (s.startsWith("p:")) return Buffer.from(s.slice(2), "base64").toString("utf8");
  } catch (e) {}
  return "";
}
function api() {
  const c = load();
  const id = +c.apiId, hash = dec(c.apiHash);
  if (!id || !hash) throw new Error("API kaliti kiritilmagan");
  return { apiId: id, apiHash: hash };
}
function mkClient(sessionStr) {
  const a = api();
  const cl = new TelegramClient(new StringSession(sessionStr || ""), a.apiId, a.apiHash, {
    connectionRetries: 3, deviceModel: "Qulay Prays", appVersion: "1.0", systemVersion: "Windows"
  });
  try { cl.setLogLevel("error"); } catch (e) {}
  return cl;
}
function errText(e) {
  const m = String((e && (e.errorMessage || e.message)) || e || "");
  if (/PHONE_NUMBER_INVALID/.test(m)) return "Telefon raqami noto'g'ri.";
  if (/PHONE_CODE_INVALID/.test(m)) return "Kod noto'g'ri.";
  if (/PHONE_CODE_EXPIRED/.test(m)) return "Kod eskirgan. Qaytadan kod so'rang.";
  if (/PASSWORD_HASH_INVALID/.test(m)) return "Ikki bosqichli parol noto'g'ri.";
  if (/FLOOD_WAIT_(\d+)/.test(m)) return "Telegram kutishni so'radi: " + m.match(/FLOOD_WAIT_(\d+)/)[1] + " soniya.";
  if (/API_ID_INVALID|API_ID_PUBLISHED_FLOOD/.test(m)) return "api_id yoki api_hash noto'g'ri.";
  if (/API kaliti/.test(m)) return m;
  return m || "Noma'lum xato";
}

// --- ulangan akkauntlar (xotirada) ---
const clients = new Map();   // accId -> { cl, ents: Map(chatId -> entity) }
async function clientOf(acc) {
  let x = clients.get(acc.id);
  if (x && x.cl.connected) return x;
  const cl = x ? x.cl : mkClient(dec(acc.session));
  await cl.connect();
  if (!(await cl.checkAuthorization())) throw new Error("Akkaunt chiqib ketgan: " + (acc.name || acc.phone) + ". Uni o'chirib, qaytadan qo'shing.");
  x = { cl, ents: new Map() };
  clients.set(acc.id, x);
  return x;
}
async function dialogsOf(acc) {
  const x = await clientOf(acc);
  const ds = await x.cl.getDialogs({ limit: 500 });
  const out = [];
  for (const d of ds) {
    const ent = d.entity; if (!ent) continue;
    const self = !!(d.isUser && ent.self);
    if (!(d.isChannel || d.isGroup || self)) continue;
    const id = String(d.id);
    x.ents.set(id, ent);
    out.push({ id, title: self ? "Saqlangan xabarlar" : (d.title || d.name || id), kind: self ? "saved" : (d.isChannel && !d.isGroup ? "kanal" : "guruh") });
  }
  return out;
}

// --- yangi akkaunt qo'shish: raqam -> kod -> (parol) ---
const pending = new Map();   // token -> { cl, phone, hash, at }
function cleanPending() { const now = Date.now(); for (const [k, v] of pending) if (now - v.at > 15 * 60 * 1000) { try { v.cl.disconnect(); } catch (e) {} pending.delete(k); } }
async function finishLogin(p) {
  const me = await p.cl.getMe();
  const c = load();
  const id = String(me.id);
  const name = [me.firstName, me.lastName].filter(Boolean).join(" ") || (me.username ? "@" + me.username : p.phone);
  const acc = { id, name, phone: me.phone ? "+" + String(me.phone).replace(/^\+/, "") : p.phone, session: enc(p.cl.session.save()), chats: [] };
  const old = c.accounts.findIndex(a => a.id === id);
  if (old >= 0) { acc.chats = c.accounts[old].chats || []; c.accounts[old] = acc; } else c.accounts.push(acc);
  save();
  clients.set(id, { cl: p.cl, ents: new Map() });
  return { ok: true, account: { id, name, phone: acc.phone } };
}

const cmds = {
  async status() {
    const c = load();
    return { hasApi: !!(c.apiId && c.apiHash), apiId: c.apiId || "", accounts: c.accounts.map(a => ({ id: a.id, name: a.name, phone: a.phone, chats: a.chats || [] })) };
  },
  async setApi(a) {
    const id = parseInt(a && a.apiId, 10), hash = String((a && a.apiHash) || "").trim();
    if (!id || !/^[0-9a-f]{32}$/i.test(hash)) throw new Error("api_id raqam, api_hash esa 32 belgili bo'lishi kerak.");
    const c = load(); c.apiId = id; c.apiHash = enc(hash); save();
    for (const [, x] of clients) { try { await x.cl.disconnect(); } catch (e) {} }
    clients.clear();
    return { ok: true };
  },
  async addStart(a) {
    cleanPending();
    const phone = String((a && a.phone) || "").replace(/[^\d+]/g, "");
    if (phone.replace(/\D/g, "").length < 9) throw new Error("Telefon raqamini to'liq yozing, masalan +998901234567.");
    const cl = mkClient("");
    await cl.connect();
    const r = await cl.sendCode(api(), phone);
    const token = crypto.randomBytes(12).toString("hex");
    pending.set(token, { cl, phone, hash: r.phoneCodeHash, at: Date.now() });
    return { token, viaApp: !!r.isCodeViaApp };
  },
  async addCode(a) {
    const p = pending.get(String(a && a.token)); if (!p) throw new Error("Vaqt o'tib ketdi. Qaytadan boshlang.");
    const code = String((a && a.code) || "").replace(/\D/g, "");
    try {
      await p.cl.invoke(new Api.auth.SignIn({ phoneNumber: p.phone, phoneCodeHash: p.hash, phoneCode: code }));
    } catch (e) {
      if (String(e && e.errorMessage) === "SESSION_PASSWORD_NEEDED") return { needPassword: true };
      throw e;
    }
    pending.delete(String(a.token));
    return finishLogin(p);
  },
  async addPassword(a) {
    const p = pending.get(String(a && a.token)); if (!p) throw new Error("Vaqt o'tib ketdi. Qaytadan boshlang.");
    let last = null;
    try {
      await p.cl.signInWithPassword(api(), { password: async () => String((a && a.password) || ""), onError: async (e) => { last = e; return true; } });
    } catch (e) { throw last || e; }
    pending.delete(String(a.token));
    return finishLogin(p);
  },
  async chats(a) {
    const acc = load().accounts.find(x => x.id === String(a && a.id)); if (!acc) throw new Error("Akkaunt topilmadi.");
    const list = await dialogsOf(acc);
    const on = new Set((acc.chats || []).map(c => c.id));
    return list.map(d => Object.assign(d, { on: on.has(d.id) }));
  },
  async setChats(a) {
    const c = load(), acc = c.accounts.find(x => x.id === String(a && a.id)); if (!acc) throw new Error("Akkaunt topilmadi.");
    acc.chats = (Array.isArray(a.chats) ? a.chats : []).map(x => ({ id: String(x.id), title: String(x.title || "") }));
    save(); return { ok: true };
  },
  async remove(a) {
    const c = load(), i = c.accounts.findIndex(x => x.id === String(a && a.id)); if (i < 0) return { ok: true };
    const acc = c.accounts[i];
    try { const x = await clientOf(acc); await x.cl.invoke(new Api.auth.LogOut()); await x.cl.disconnect(); } catch (e) {}
    clients.delete(acc.id);
    c.accounts.splice(i, 1); delete c.seen[acc.id]; save();
    return { ok: true };
  },
  async fetchNew() {
    const c = load(), out = [], errs = [];
    if (!c.apiId || !c.apiHash) return { items: out, errors: ["API kaliti kiritilmagan."] };
    const since = Math.floor(Date.now() / 1000) - FIRST_DAYS * 86400;
    for (const acc of c.accounts) {
      if (!acc.chats || !acc.chats.length) continue;
      try {
        const x = await clientOf(acc);
        if (acc.chats.some(ch => !x.ents.has(ch.id))) await dialogsOf(acc);
        c.seen[acc.id] = c.seen[acc.id] || {};
        for (const ch of acc.chats) {
          const ent = x.ents.get(ch.id); if (!ent) continue;
          const last = +c.seen[acc.id][ch.id] || 0;
          const msgs = await x.cl.getMessages(ent, last ? { limit: 100, minId: last } : { limit: 60 });
          let top = last;
          const list = Array.from(msgs || []).sort((m1, m2) => m1.id - m2.id);
          for (const m of list) {
            if (m.id > top) top = m.id;
            if (!last && m.date < since) continue;
            const doc = m.media && m.media.document;
            if (!doc || !(m.media instanceof Api.MessageMediaDocument)) continue;
            const fa = (doc.attributes || []).find(t => t instanceof Api.DocumentAttributeFilename);
            const name = fa && fa.fileName; if (!name || !EXT.test(name)) continue;
            if (+doc.size > MAX_FILE) continue;
            const buf = await x.cl.downloadMedia(m, {});
            if (!buf || !buf.length) continue;
            let src = ch.title;
            try { const fw = m.fwdFrom; if (fw && fw.fromName) src = fw.fromName; else if (fw && fw.fromId && fw.fromId.channelId) { const fe = await x.cl.getEntity(fw.fromId); if (fe && fe.title) src = fe.title; } } catch (e) {}
            out.push({
              account: acc.name || acc.phone, chatId: ch.id + (src !== ch.title ? ":" + src : ""), chatTitle: src, msgId: m.id,
              date: new Date(m.date * 1000).toISOString(), fileName: name,
              hash: crypto.createHash("sha1").update(buf).digest("hex"), data: new Uint8Array(buf)
            });
          }
          if (top > last) c.seen[acc.id][ch.id] = top;
        }
      } catch (e) { errs.push((acc.name || acc.phone) + ": " + errText(e)); }
    }
    save();
    return { items: out, errors: errs };
  }
};

let busy = Promise.resolve();
async function run(cmd, arg) {
  const fn = cmds[cmd]; if (!fn) throw new Error("bad cmd");
  // buyruqlar navbat bilan bajariladi
  const p = busy.then(() => fn(arg));
  busy = p.catch(() => {});
  try { return await p; } catch (e) { throw new Error(errText(e)); }
}
module.exports = { run };
