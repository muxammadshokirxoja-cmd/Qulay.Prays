const { contextBridge, ipcRenderer } = require("electron");
contextBridge.exposeInMainWorld("qpDesktop", {
  save: (text, build) => ipcRenderer.invoke("qp:save", text, build),
  reload: () => ipcRenderer.invoke("qp:reload"),
  toggleMax: () => ipcRenderer.invoke("qp:togglemax"),
  isMax: () => ipcRenderer.invoke("qp:ismax"),
  tg: {
    status: () => ipcRenderer.invoke("qp:tg", "status"),
    setApi: (apiId, apiHash) => ipcRenderer.invoke("qp:tg", "setApi", { apiId, apiHash }),
    addStart: (phone) => ipcRenderer.invoke("qp:tg", "addStart", { phone }),
    addCode: (token, code) => ipcRenderer.invoke("qp:tg", "addCode", { token, code }),
    addPassword: (token, password) => ipcRenderer.invoke("qp:tg", "addPassword", { token, password }),
    chats: (id) => ipcRenderer.invoke("qp:tg", "chats", { id }),
    setChats: (id, chats) => ipcRenderer.invoke("qp:tg", "setChats", { id, chats }),
    remove: (id) => ipcRenderer.invoke("qp:tg", "remove", { id }),
    fetchNew: () => ipcRenderer.invoke("qp:tg", "fetchNew")
  }
});
